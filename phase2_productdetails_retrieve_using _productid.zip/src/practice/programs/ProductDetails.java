package practice.programs;

public class ProductDetails
{
	int Id;
	String Name;
	float Price;
	public int getId() {
		return Id;
	}
	public void setId(int id) 
	{
		this.Id = id;
	}
	public String getName() 
	{
		return Name;
	}
	public void setName(String name)
	{
		this.Name = name;
	}
	public float getPrice() 
	{
		return Price;
	}
	public void setPrice(float price) 
	{
		Price = price;
	}
}
